


#!/bin/bash
#
# SBSN framework - Preprocessing
# June 2022
#
# Preparation of functional spine data
#
# Requirements: FSL, Spinal Cord Toolbox 5.5
#
# SPINE

#set -x
# Immediately exit if error
#set -e -o pipefail

# Exit if user presses CTRL+C (Linux) or CMD+C (OSX)
trap "echo Caught Keyboard Interrupt within script. Exiting now.; exit" INT

# Save script path
#PATH_SCRIPT=$PWD

# get starting time:
start=`date +%s`
####################################

# load in function that has paths to subject
. /mnt/d/SBSN/Processing_Spine/path_to_subjects.sh 

tput setaf 6; 
echo -n "Enter the index of the step to perform (1 = Prepare for GLM, 2 = Prepare for force GLM, 3 = Prepare for FLOB force GLM, 4 = Prepare for FLOB smoothed force GLM, 5 = Prepare for iCAP): "
tput sgr0;
read ind


# For each subject
for s in "${sub[@]}"; do

	cd $DIREC$s"/func/"

    for d in "${myFunc[@]}"; do

        if [ "$ind" == "1" ]; then

            tput setaf 2; echo "Prepare second level analysis for GLM " $s"/func/func"$d
            tput sgr0; 

            # Will print */ if no directories are available
            cd $DIREC$s"/func/func"$d"/"

            tput setaf 2; echo "Moving files " $s"/func/func"$d	

            cp -r "$DIREC"reg/"" $DIREC$s"/func/func"$d"/level_one.feat/"
            
            # these have to be the same size across all subject because they get concatenated in the 4th dimension
            # change this to the PAM50 template
            cp ../../../template/PAM50_t2s.nii.gz level_one.feat/reg/standard.nii.gz
            cp ../../../template/PAM50_t2s.nii.gz level_one.feat/reg/example_func.nii.gz

            cp anat2template.nii.gz level_one.feat/example_func.nii.gz
            cp anat2template.nii.gz level_one.feat/mean_func.nii.gz

            if [ -f level_one.feat/stats/subjectSpace_cope1.nii.gz ]; then

                # files have already been transofrmed
                # subject space images are original images so just apply warps to them
                # no need to rename files again
                sct_apply_transfo -i level_one.feat/stats/subjectSpace_cope1.nii.gz -d ../../../template/PAM50_t2s.nii.gz -w warp_anat2template.nii.gz -o level_one.feat/stats/cope1.nii.gz

                sct_apply_transfo -i level_one.feat/stats/subjectSpace_varcope1.nii.gz -d ../../../template/PAM50_t2s.nii.gz -w warp_anat2template.nii.gz -o level_one.feat/stats/varcope1.nii.gz

                # i think this mask may have to be replaced with the PAM50 mask that we want to use
                cp ../../../template/PAM50_cervical_cord.nii.gz level_one.feat/mask.nii.gz
                #sct_apply_transfo -i level_one.feat/subjectSpace_mask.nii.gz -d ../../../template/PAM50_t2s.nii.gz -w warp_anat2template.nii.gz -o level_one.feat/mask.nii.gz

            else

                # rename file then apply a transform to it so its located in PAM50 space
                mv level_one.feat/stats/cope1.nii.gz level_one.feat/stats/subjectSpace_cope1.nii.gz
                #sleep 10
                sct_apply_transfo -i level_one.feat/stats/subjectSpace_cope1.nii.gz -d ../../../template/PAM50_t2s.nii.gz -w warp_anat2template.nii.gz -o level_one.feat/stats/cope1.nii.gz

                mv level_one.feat/stats/varcope1.nii.gz level_one.feat/stats/subjectSpace_varcope1.nii.gz
                #sleep 10
                sct_apply_transfo -i level_one.feat/stats/subjectSpace_varcope1.nii.gz -d ../../../template/PAM50_t2s.nii.gz -w warp_anat2template.nii.gz -o level_one.feat/stats/varcope1.nii.gz

                # i think this mask may have to be replaced with the PAM50 mask that we want to use
                mv level_one.feat/mask.nii.gz level_one.feat/subjectSpace_mask.nii.gz
                cp ../../../template/PAM50_cervical_cord.nii.gz level_one.feat/mask.nii.gz

            fi

        elif [ "$ind" == "2" ]; then

            tput setaf 2; echo "Prepare second level analysis for GLM " $s"/func/func"$d
            tput sgr0; 

            # Will print */ if no directories are available
            cd $DIREC$s"/func/func"$d"/"

            tput setaf 2; echo "Moving files " $s"/func/func"$d	

            cp -r "$DIREC"reg/"" $DIREC$s"/func/func"$d"/level_one_force.feat/"
            
            # these have to be the same size across all subject because they get concatenated in the 4th dimension
            # change this to the PAM50 template
            cp ../../../template/PAM50_t2s.nii.gz level_one_force.feat/reg/standard.nii.gz
            cp ../../../template/PAM50_t2s.nii.gz level_one_force.feat/reg/example_func.nii.gz

            cp anat2template.nii.gz level_one_force.feat/example_func.nii.gz
            cp anat2template.nii.gz level_one_force.feat/mean_func.nii.gz
            
            totalCopes=(1 2 3 4 5 6)
            for copeNum in "${totalCopes[@]}"; do
                
                # do two differnt if statements for both the cope and var cope to avoid outlier cases of overwriting
                if [ -f "level_one_force.feat/stats/subjectSpace_cope"$copeNum".nii.gz" ]; then
                    tput setaf 1; 
                    echo $DIREC$s"/func/func"$d"/level_one_force.feat/stats/cope"$copeNum

                    tput setaf 6;
                    # files have already been transofrmed
                    # subject space images are original images so just apply warps to them
                    # no need to rename files again
                    sct_apply_transfo -i "level_one_force.feat/stats/subjectSpace_cope"$copeNum".nii.gz" -d ../../../template/PAM50_t2s.nii.gz -w warp_anat2template.nii.gz -o "level_one_force.feat/stats/cope"$copeNum".nii.gz"

                else
                    tput setaf 1; 
                    echo $DIREC$s"/func/func"$d"/level_one_force.feat/stats/cope"$copeNum

                    tput setaf 6;   
                    # rename file then apply a transform to it so its located in PAM50 space
                    mv "level_one_force.feat/stats/cope"$copeNum".nii.gz" "level_one_force.feat/stats/subjectSpace_cope"$copeNum".nii.gz"

                    sct_apply_transfo -i "level_one_force.feat/stats/subjectSpace_cope"$copeNum".nii.gz" -d ../../../template/PAM50_t2s.nii.gz -w warp_anat2template.nii.gz -o "level_one_force.feat/stats/cope"$copeNum".nii.gz"

                fi

                # another if statement that does same as above except for varcope file
                if [ -f "level_one_force.feat/stats/subjectSpace_varcope"$copeNum".nii.gz" ]; then
                    tput setaf 1;  
                    echo $DIREC$s"/func/func"$d"/level_one_force.feat/stats/varcope"$copeNum

                    tput setaf 6;
                    # files have already been transofrmed
                    # subject space images are original images so just apply warps to them
                    # no need to rename files again
                    sct_apply_transfo -i "level_one_force.feat/stats/subjectSpace_varcope"$copeNum".nii.gz" -d ../../../template/PAM50_t2s.nii.gz -w warp_anat2template.nii.gz -o "level_one_force.feat/stats/varcope"$copeNum".nii.gz"

                else
                    tput setaf 1; 
                    echo $DIREC$s"/func/func"$d"/level_one_force.feat/stats/varcope"$copeNum

                    tput setaf 6;
                    mv "level_one_force.feat/stats/varcope"$copeNum".nii.gz" "level_one_force.feat/stats/subjectSpace_varcope"$copeNum".nii.gz"

                    sct_apply_transfo -i "level_one_force.feat/stats/subjectSpace_varcope"$copeNum".nii.gz" -d ../../../template/PAM50_t2s.nii.gz -w warp_anat2template.nii.gz -o "level_one_force.feat/stats/varcope"$copeNum".nii.gz"

                fi

            done

            if [ -f level_one_force.feat/stats/subjectSpace_mask.nii.gz ]; then

                cp ../../../template/PAM50_cervical_cord.nii.gz level_one_force.feat/mask.nii.gz
                # why we dont use this transform below and use the one above instead
                #sct_apply_transfo -i level_one_force.feat/subjectSpace_mask.nii.gz -d ../../../template/PAM50_t2s.nii.gz -w warp_anat2template.nii.gz -o level_one_force.feat/mask.nii.gz

            else

                # i think this mask may have to be replaced with the PAM50 mask that we want to use
                mv level_one_force.feat/mask.nii.gz level_one_force.feat/subjectSpace_mask.nii.gz
                cp ../../../template/PAM50_cervical_cord.nii.gz level_one_force.feat/mask.nii.gz

            fi

        elif [ "$ind" == "3" ]; then

            tput setaf 2; echo "Prepare second level analysis for GLM " $s"/func/func"$d
            tput sgr0; 

            cd $DIREC$s"/func/func"$d"/"

            tput setaf 2; echo "Moving files " $s"/func/func"$d	

            cp -r "$DIREC"reg/"" $DIREC$s"/func/func"$d"/level_one_FLOB.feat/"
            
            # these have to be the same size across all subject because they get concatenated in the 4th dimension
            # change this to the PAM50 template
            cp ../../../template/PAM50_t2s.nii.gz level_one_FLOB.feat/reg/standard.nii.gz
            cp ../../../template/PAM50_t2s.nii.gz level_one_FLOB.feat/reg/example_func.nii.gz

            cp anat2template.nii.gz level_one_FLOB.feat/example_func.nii.gz
            cp anat2template.nii.gz level_one_FLOB.feat/mean_func.nii.gz
            
            mkdir level_one_FLOB.feat/reg_standard
            mkdir level_one_FLOB.feat/reg_standard/reg
            mkdir level_one_FLOB.feat/reg_standard/stats

            totalCopes=(1 2 3)
            for copeNum in "${totalCopes[@]}"; do
                
                # do two different if statements for both the cope and var cope to avoid outlier cases of overwriting
                if [ -f "level_one_FLOB.feat/stats/subjectSpace_cope"$copeNum".nii.gz" ]; then

                    tput setaf 1; 
                    echo $DIREC$s"/func/func"$d"/level_one_FLOB.feat/stats/cope"$copeNum

                    tput setaf 6;
                    # files have already been transofrmed
                    # subject space images are original images so just apply warps to them
                    # no need to rename files again
                    sct_apply_transfo -i "level_one_FLOB.feat/stats/subjectSpace_cope"$copeNum".nii.gz" -d ../../../template/PAM50_t2s.nii.gz -w warp_anat2template.nii.gz -o "level_one_FLOB.feat/stats/cope"$copeNum".nii.gz"

                    tput setaf 1;  
                    echo "Error checking cope"$copeNum
                    tput setaf 6;

                    # this is where second level always fails
                    # so I run the command myslef to error check and reapply the transoformation if this fails
                    # it will create a new file if passes and nothing if fails
                    flirt -ref level_one_FLOB.feat/reg/standard -in "level_one_FLOB.feat/stats/cope"$copeNum".nii.gz" -out "level_one_FLOB.feat/reg_standard/stats/cope"$copeNum".nii.gz" -applyxfm -init level_one_FLOB.feat/reg/example_func2standard.mat -interp trilinear -datatype float


                else 

                    # rename file then apply a transform to it so its located in PAM50 space
                    mv "level_one_FLOB.feat/stats/cope"$copeNum".nii.gz" "level_one_FLOB.feat/stats/subjectSpace_cope"$copeNum".nii.gz"

                    tput setaf 1; 
                    echo $DIREC$s"/func/func"$d"/level_one_FLOB.feat/stats/cope"$copeNum

                    tput setaf 6;
                    # files have already been transofrmed
                    # subject space images are original images so just apply warps to them
                    # no need to rename files again
                    sct_apply_transfo -i "level_one_FLOB.feat/stats/subjectSpace_cope"$copeNum".nii.gz" -d ../../../template/PAM50_t2s.nii.gz -w warp_anat2template.nii.gz -o "level_one_FLOB.feat/stats/cope"$copeNum".nii.gz"

                    tput setaf 1;  
                    echo "Error checking cope"$copeNum
                    tput setaf 6;
                    
                    # this is where second level always fails
                    # so I run the command myslef to error check and reapply the transoformation if this fails
                    # it will create a new file if passes and nothing if fails
                    flirt -ref level_one_FLOB.feat/reg/standard -in "level_one_FLOB.feat/stats/cope"$copeNum".nii.gz" -out "level_one_FLOB.feat/reg_standard/stats/cope"$copeNum".nii.gz" -applyxfm -init level_one_FLOB.feat/reg/example_func2standard.mat -interp trilinear -datatype float

                fi

                # another if statement that does same as above except for varcope file
                if [ -f "level_one_FLOB.feat/stats/subjectSpace_varcope"$copeNum".nii.gz" ]; then

                    tput setaf 1;  
                    echo $DIREC$s"/func/func"$d"/level_one_FLOB.feat/stats/varcope"$copeNum

                    tput setaf 6;
                    # files have already been transofrmed
                    # subject space images are original images so just apply warps to them
                    # no need to rename files again
                    sct_apply_transfo -i "level_one_FLOB.feat/stats/subjectSpace_varcope"$copeNum".nii.gz" -d ../../../template/PAM50_t2s.nii.gz -w warp_anat2template.nii.gz -o "level_one_FLOB.feat/stats/varcope"$copeNum".nii.gz"

                    tput setaf 1;  
                    echo "Error checking varcope"$copeNum
                    tput setaf 6;   
                       
                    # this is where second level always fails
                    # so I run the command myslef to error check and reapply the transoformation if this fails
                    # it will create a new file if passes and nothing if fails
                    flirt -ref level_one_FLOB.feat/reg/standard -in "level_one_FLOB.feat/stats/varcope"$copeNum".nii.gz" -out "level_one_FLOB.feat/reg_standard/stats/varcope"$copeNum".nii.gz" -applyxfm -init level_one_FLOB.feat/reg/example_func2standard.mat -interp trilinear -datatype float

                else
                    mv "level_one_FLOB.feat/stats/varcope"$copeNum".nii.gz" "level_one_FLOB.feat/stats/subjectSpace_varcope"$copeNum".nii.gz"

                    tput setaf 1;  
                    echo $DIREC$s"/func/func"$d"/level_one_FLOB.feat/stats/varcope"$copeNum

                    tput setaf 6;
                    # files have already been transofrmed
                    # subject space images are original images so just apply warps to them
                    # no need to rename files again
                    sct_apply_transfo -i "level_one_FLOB.feat/stats/subjectSpace_varcope"$copeNum".nii.gz" -d ../../../template/PAM50_t2s.nii.gz -w warp_anat2template.nii.gz -o "level_one_FLOB.feat/stats/varcope"$copeNum".nii.gz"

                    tput setaf 1;  
                    echo "Error checking varcope"$copeNum
                    tput setaf 6;   
             
                    # this is where second level always fails
                    # so I run the command myslef to error check and reapply the transoformation if this fails
                    # it will create a new file if passes and nothing if fails
                    flirt -ref level_one_FLOB.feat/reg/standard -in "level_one_FLOB.feat/stats/varcope"$copeNum".nii.gz" -out "level_one_FLOB.feat/reg_standard/stats/varcope"$copeNum".nii.gz" -applyxfm -init level_one_FLOB.feat/reg/example_func2standard.mat -interp trilinear -datatype float

                fi

            done

            if [ -f level_one_FLOB.feat/stats/subjectSpace_mask.nii.gz ]; then

                cp ../../../template/PAM50_cervical_cord.nii.gz level_one_FLOB.feat/mask.nii.gz
                # why we dont use this transform below and use the one above instead
                #sct_apply_transfo -i level_one_force_FLOB.feat/subjectSpace_mask.nii.gz -d ../../../template/PAM50_t2s.nii.gz -w warp_anat2template.nii.gz -o level_one_force_FLOB.feat/mask.nii.gz

            else

                # i think this mask may have to be replaced with the PAM50 mask that we want to use
                mv level_one_FLOB.feat/mask.nii.gz level_one_FLOB.feat/subjectSpace_mask.nii.gz
                cp ../../../template/PAM50_cervical_cord.nii.gz level_one_FLOB.feat/mask.nii.gz

            fi

        elif [ "$ind" == "99" ]; then

            tput setaf 2; echo "Prepare second level analysis for GLM " $s"/func/func"$d
            tput sgr0; 

            cd $DIREC$s"/func/func"$d"/"

            tput setaf 2; echo "Moving files " $s"/func/func"$d 

            cp -r "$DIREC"reg/"" $DIREC$s"/func/func"$d"/level_one_force_FLOB.feat/"
            
            # these have to be the same size across all subject because they get concatenated in the 4th dimension
            # change this to the PAM50 template
            cp ../../../template/PAM50_t2s.nii.gz level_one_force_FLOB.feat/reg/standard.nii.gz
            cp ../../../template/PAM50_t2s.nii.gz level_one_force_FLOB.feat/reg/example_func.nii.gz

            cp anat2template.nii.gz level_one_force_FLOB.feat/example_func.nii.gz
            cp anat2template.nii.gz level_one_force_FLOB.feat/mean_func.nii.gz
            
            mkdir level_one_force_FLOB.feat/reg_standard
            mkdir level_one_force_FLOB.feat/reg_standard/reg
            mkdir level_one_force_FLOB.feat/reg_standard/stats

            totalCopes=(1 2 3 4 5 6 7 8 9)
            for copeNum in "${totalCopes[@]}"; do
                
                # do two different if statements for both the cope and var cope to avoid outlier cases of overwriting
                if [ -f "level_one_force_FLOB.feat/stats/subjectSpace_cope"$copeNum".nii.gz" ]; then

                    tput setaf 1; 
                    echo $DIREC$s"/func/func"$d"/level_one_force_FLOB.feat/stats/cope"$copeNum

                    tput setaf 6;
                    # files have already been transofrmed
                    # subject space images are original images so just apply warps to them
                    # no need to rename files again
                    sct_apply_transfo -i "level_one_force_FLOB.feat/stats/subjectSpace_cope"$copeNum".nii.gz" -d ../../../template/PAM50_t2s.nii.gz -w warp_anat2template.nii.gz -o "level_one_force_FLOB.feat/stats/cope"$copeNum".nii.gz"

                    tput setaf 1;  
                    echo "Error checking cope"$copeNum
                    tput setaf 6;

                    # this is where second level always fails
                    # so I run the command myslef to error check and reapply the transoformation if this fails
                    # it will create a new file if passes and nothing if fails
                    flirt -ref level_one_force_FLOB.feat/reg/standard -in "level_one_force_FLOB.feat/stats/cope"$copeNum".nii.gz" -out "level_one_force_FLOB.feat/reg_standard/stats/cope"$copeNum".nii.gz" -applyxfm -init level_one_force_FLOB.feat/reg/example_func2standard.mat -interp trilinear -datatype float


                else 

                    # rename file then apply a transform to it so its located in PAM50 space
                    mv "level_one_force_FLOB.feat/stats/cope"$copeNum".nii.gz" "level_one_force_FLOB.feat/stats/subjectSpace_cope"$copeNum".nii.gz"

                    tput setaf 1; 
                    echo $DIREC$s"/func/func"$d"/level_one_force_FLOB.feat/stats/cope"$copeNum

                    tput setaf 6;
                    # files have already been transofrmed
                    # subject space images are original images so just apply warps to them
                    # no need to rename files again
                    sct_apply_transfo -i "level_one_force_FLOB.feat/stats/subjectSpace_cope"$copeNum".nii.gz" -d ../../../template/PAM50_t2s.nii.gz -w warp_anat2template.nii.gz -o "level_one_force_FLOB.feat/stats/cope"$copeNum".nii.gz"

                    tput setaf 1;  
                    echo "Error checking cope"$copeNum
                    tput setaf 6;
                    
                    # this is where second level always fails
                    # so I run the command myslef to error check and reapply the transoformation if this fails
                    # it will create a new file if passes and nothing if fails
                    flirt -ref level_one_force_FLOB.feat/reg/standard -in "level_one_force_FLOB.feat/stats/cope"$copeNum".nii.gz" -out "level_one_force_FLOB.feat/reg_standard/stats/cope"$copeNum".nii.gz" -applyxfm -init level_one_force_FLOB.feat/reg/example_func2standard.mat -interp trilinear -datatype float

                fi

                # another if statement that does same as above except for varcope file
                if [ -f "level_one_force_FLOB.feat/stats/subjectSpace_varcope"$copeNum".nii.gz" ]; then

                    tput setaf 1;  
                    echo $DIREC$s"/func/func"$d"/level_one_force_FLOB.feat/stats/varcope"$copeNum

                    tput setaf 6;
                    # files have already been transofrmed
                    # subject space images are original images so just apply warps to them
                    # no need to rename files again
                    sct_apply_transfo -i "level_one_force_FLOB.feat/stats/subjectSpace_varcope"$copeNum".nii.gz" -d ../../../template/PAM50_t2s.nii.gz -w warp_anat2template.nii.gz -o "level_one_force_FLOB.feat/stats/varcope"$copeNum".nii.gz"

                    tput setaf 1;  
                    echo "Error checking varcope"$copeNum
                    tput setaf 6;   
                       
                    # this is where second level always fails
                    # so I run the command myslef to error check and reapply the transoformation if this fails
                    # it will create a new file if passes and nothing if fails
                    flirt -ref level_one_force_FLOB.feat/reg/standard -in "level_one_force_FLOB.feat/stats/varcope"$copeNum".nii.gz" -out "level_one_force_FLOB.feat/reg_standard/stats/varcope"$copeNum".nii.gz" -applyxfm -init level_one_force_FLOB.feat/reg/example_func2standard.mat -interp trilinear -datatype float

                else
                    mv "level_one_force_FLOB.feat/stats/varcope"$copeNum".nii.gz" "level_one_force_FLOB.feat/stats/subjectSpace_varcope"$copeNum".nii.gz"

                    tput setaf 1;  
                    echo $DIREC$s"/func/func"$d"/level_one_force_FLOB.feat/stats/varcope"$copeNum

                    tput setaf 6;
                    # files have already been transofrmed
                    # subject space images are original images so just apply warps to them
                    # no need to rename files again
                    sct_apply_transfo -i "level_one_force_FLOB.feat/stats/subjectSpace_varcope"$copeNum".nii.gz" -d ../../../template/PAM50_t2s.nii.gz -w warp_anat2template.nii.gz -o "level_one_force_FLOB.feat/stats/varcope"$copeNum".nii.gz"

                    tput setaf 1;  
                    echo "Error checking varcope"$copeNum
                    tput setaf 6;   
             
                    # this is where second level always fails
                    # so I run the command myslef to error check and reapply the transoformation if this fails
                    # it will create a new file if passes and nothing if fails
                    flirt -ref level_one_force_FLOB.feat/reg/standard -in "level_one_force_FLOB.feat/stats/varcope"$copeNum".nii.gz" -out "level_one_force_FLOB.feat/reg_standard/stats/varcope"$copeNum".nii.gz" -applyxfm -init level_one_force_FLOB.feat/reg/example_func2standard.mat -interp trilinear -datatype float

                fi

            done

            if [ -f level_one_force_FLOB.feat/stats/subjectSpace_mask.nii.gz ]; then

                cp ../../../template/PAM50_cervical_cord.nii.gz level_one_force_FLOB.feat/mask.nii.gz
                # why we dont use this transform below and use the one above instead
                #sct_apply_transfo -i level_one_force_FLOB.feat/subjectSpace_mask.nii.gz -d ../../../template/PAM50_t2s.nii.gz -w warp_anat2template.nii.gz -o level_one_force_FLOB.feat/mask.nii.gz

            else

                # i think this mask may have to be replaced with the PAM50 mask that we want to use
                mv level_one_force_FLOB.feat/mask.nii.gz level_one_force_FLOB.feat/subjectSpace_mask.nii.gz
                cp ../../../template/PAM50_cervical_cord.nii.gz level_one_force_FLOB.feat/mask.nii.gz

            fi

        elif [ "$ind" == "4" ]; then

            tput setaf 2; echo "Prepare second level analysis for GLM " $s"/func/func"$d
            tput sgr0; 

            cd $DIREC$s"/func/func"$d"/"

            tput setaf 2; echo "Moving files " $s"/func/func"$d	

            cp -r "$DIREC"reg/"" $DIREC$s"/func/func"$d"/level_one_force_smooth_FLOB.feat/"
            
            # these have to be the same size across all subject because they get concatenated in the 4th dimension
            # change this to the PAM50 template
            cp ../../../template/PAM50_t2s.nii.gz level_one_force_smooth_FLOB.feat/reg/standard.nii.gz
            cp ../../../template/PAM50_t2s.nii.gz level_one_force_smooth_FLOB.feat/reg/example_func.nii.gz

            cp anat2template.nii.gz level_one_force_smooth_FLOB.feat/example_func.nii.gz
            cp anat2template.nii.gz level_one_force_smooth_FLOB.feat/mean_func.nii.gz
            
            mkdir level_one_force_smooth_FLOB.feat/reg_standard
            mkdir level_one_force_smooth_FLOB.feat/reg_standard/reg
            mkdir level_one_force_smooth_FLOB.feat/reg_standard/stats

            totalCopes=(1 2 3 4 5 6 7 8 9)
            for copeNum in "${totalCopes[@]}"; do
                
                # do two different if statements for both the cope and var cope to avoid outlier cases of overwriting
                if [ -f "level_one_force_smooth_FLOB.feat/stats/subjectSpace_cope"$copeNum".nii.gz" ]; then


                    tput setaf 1; 
                    echo $DIREC$s"/func/func"$d"/level_one_force_smooth_FLOB.feat/stats/cope"$copeNum

                    tput setaf 6;
                    # files have already been transofrmed
                    # subject space images are original images so just apply warps to them
                    # no need to rename files again
                    sct_apply_transfo -i "level_one_force_smooth_FLOB.feat/stats/subjectSpace_cope"$copeNum".nii.gz" -d ../../../template/PAM50_t2s.nii.gz -w warp_anat2template.nii.gz -o "level_one_force_smooth_FLOB.feat/stats/cope"$copeNum".nii.gz"

                    tput setaf 1;  
                    echo "Error checking cope"$copeNum
                    tput setaf 6;

                    # this is where second level always fails
                    # so I run the command myslef to error check and reapply the transoformation if this fails
                    # it will create a new file if passes and nothing if fails
                    flirt -ref level_one_force_smooth_FLOB.feat/reg/standard -in "level_one_force_smooth_FLOB.feat/stats/cope"$copeNum".nii.gz" -out "level_one_force_smooth_FLOB.feat/reg_standard/stats/cope"$copeNum".nii.gz" -applyxfm -init level_one_force_smooth_FLOB.feat/reg/example_func2standard.mat -interp trilinear -datatype float


                else 
                    # rename file then apply a transform to it so its located in PAM50 space
                    mv "level_one_force_smooth_FLOB.feat/stats/cope"$copeNum".nii.gz" "level_one_force_smooth_FLOB.feat/stats/subjectSpace_cope"$copeNum".nii.gz"

                    tput setaf 1; 
                    echo $DIREC$s"/func/func"$d"/level_one_force_smooth_FLOB.feat/stats/cope"$copeNum

                    tput setaf 6;
                    # files have already been transofrmed
                    # subject space images are original images so just apply warps to them
                    # no need to rename files again
                    sct_apply_transfo -i "level_one_force_smooth_FLOB.feat/stats/subjectSpace_cope"$copeNum".nii.gz" -d ../../../template/PAM50_t2s.nii.gz -w warp_anat2template.nii.gz -o "level_one_force_smooth_FLOB.feat/stats/cope"$copeNum".nii.gz"

                    tput setaf 1;  
                    echo "Error checking cope"$copeNum
                    tput setaf 6;
                    
                    # this is where second level always fails
                    # so I run the command myslef to error check and reapply the transoformation if this fails
                    # it will create a new file if passes and nothing if fails
                    flirt -ref level_one_force_smooth_FLOB.feat/reg/standard -in "level_one_force_smooth_FLOB.feat/stats/cope"$copeNum".nii.gz" -out "level_one_force_smooth_FLOB.feat/reg_standard/stats/cope"$copeNum".nii.gz" -applyxfm -init level_one_force_smooth_FLOB.feat/reg/example_func2standard.mat -interp trilinear -datatype float

                fi

                # another if statement that does same as above except for varcope file
                if [ -f "level_one_force_smooth_FLOB.feat/stats/subjectSpace_varcope"$copeNum".nii.gz" ]; then

                    tput setaf 1;  
                    echo $DIREC$s"/func/func"$d"/level_one_force_smooth_FLOB.feat/stats/varcope"$copeNum

                    tput setaf 6;
                    # files have already been transofrmed
                    # subject space images are original images so just apply warps to them
                    # no need to rename files again
                    sct_apply_transfo -i "level_one_force_smooth_FLOB.feat/stats/subjectSpace_varcope"$copeNum".nii.gz" -d ../../../template/PAM50_t2s.nii.gz -w warp_anat2template.nii.gz -o "level_one_force_smooth_FLOB.feat/stats/varcope"$copeNum".nii.gz"

                    tput setaf 1;  
                    echo "Error checking varcope"$copeNum
                    tput setaf 6;   
                       
                    # this is where second level always fails
                    # so I run the command myslef to error check and reapply the transoformation if this fails
                    # it will create a new file if passes and nothing if fails
                    flirt -ref level_one_force_smooth_FLOB.feat/reg/standard -in "level_one_force_smooth_FLOB.feat/stats/varcope"$copeNum".nii.gz" -out "level_one_force_smooth_FLOB.feat/reg_standard/stats/varcope"$copeNum".nii.gz" -applyxfm -init level_one_force_smooth_FLOB.feat/reg/example_func2standard.mat -interp trilinear -datatype float


                else
                    mv "level_one_force_smooth_FLOB.feat/stats/varcope"$copeNum".nii.gz" "level_one_force_smooth_FLOB.feat/stats/subjectSpace_varcope"$copeNum".nii.gz"

                    tput setaf 1;  
                    echo $DIREC$s"/func/func"$d"/level_one_force_smooth_FLOB.feat/stats/varcope"$copeNum

                    tput setaf 6;
                    # files have already been transofrmed
                    # subject space images are original images so just apply warps to them
                    # no need to rename files again
                    sct_apply_transfo -i "level_one_force_smooth_FLOB.feat/stats/subjectSpace_varcope"$copeNum".nii.gz" -d ../../../template/PAM50_t2s.nii.gz -w warp_anat2template.nii.gz -o "level_one_force_smooth_FLOB.feat/stats/varcope"$copeNum".nii.gz"

                    tput setaf 1;  
                    echo "Error checking varcope"$copeNum
                    tput setaf 6;   
             
                    # this is where second level always fails
                    # so I run the command myslef to error check and reapply the transoformation if this fails
                    # it will create a new file if passes and nothing if fails
                    flirt -ref level_one_force_smooth_FLOB.feat/reg/standard -in "level_one_force_smooth_FLOB.feat/stats/varcope"$copeNum".nii.gz" -out "level_one_force_smooth_FLOB.feat/reg_standard/stats/varcope"$copeNum".nii.gz" -applyxfm -init level_one_force_smooth_FLOB.feat/reg/example_func2standard.mat -interp trilinear -datatype float

                fi

            done

            if [ -f level_one_force_smooth_FLOB.feat/stats/subjectSpace_mask.nii.gz ]; then

                cp ../../../template/PAM50_cervical_cord.nii.gz level_one_force_smooth_FLOB.feat/mask.nii.gz
                # why we dont use this transform below and use the one above instead
                #sct_apply_transfo -i level_one_force_smooth_FLOB.feat/subjectSpace_mask.nii.gz -d ../../../template/PAM50_t2s.nii.gz -w warp_anat2template.nii.gz -o level_one_force_smooth_FLOB.feat/mask.nii.gz

            else

                # i think this mask may have to be replaced with the PAM50 mask that we want to use
                mv level_one_force_smooth_FLOB.feat/mask.nii.gz level_one_force_smooth_FLOB.feat/subjectSpace_mask.nii.gz
                cp ../../../template/PAM50_cervical_cord.nii.gz level_one_force_smooth_FLOB.feat/mask.nii.gz

            fi

        elif [ "$ind" == "5" ]; then

            cd $DIREC$s"/func/func"$d"/"

            #tput setaf 2; echo "Preparing for TA in " $s"/func/func"$d
            #tput sgr0; 

            mkdir $DIREC$s"/func/func"$d"/iCAP/TA" -p
            cd $DIREC$s"/func/func"$d"/iCAP"

            cp ../../../../template/PAM50_cervical_cord_all.nii.gz cervical_mask_all.nii.gz
            cp ../../../../template/PAM50_cervical_cord.nii.gz cervical_mask.nii.gz
            cp ../fmri_spine_moco_denoised.nii.gz TA/fmri_spine_moco_denoised_icap.nii.gz

            ################################################
            # smooth residuals
            ################################################
            #sct_maths -i "level_one_force_smooth.feat/stats/cope"$copeNum".nii.gz" -smooth 2,2,4 -o "level_one_force_smooth.feat/stats/cope"$copeNum".nii.gz"

            gunzip cervical_mask.nii.gz -f

            # first we are going to split the data along the t dimension

            tput setaf 2; echo "...Split functional data"
                    tput sgr0;

            # First, split data
            cd $DIREC$s"/func/func"$d"/iCAP/TA"
            fslsplit fmri_spine_moco_denoised_icap.nii.gz resvol -t

            for n in "$PWD"/resvol*.nii.gz; do # Loop through all files

                IFS='.' read -r volname string <<< "$n"

                sct_apply_transfo -i "${volname##*/}".nii.gz -d ../../../../../template/PAM50_t2s.nii.gz -w ../../warp_anat2template.nii.gz

                mv "${volname##*/}"_reg.nii.gz "${volname##*/}".nii.gz

                #sct_smooth_spinalcord -i "${volname##*/}".nii.gz -s ../cervical_mask_all.nii.gz -smooth 2,2,6 -o "${volname##*/}".nii.gz

                gunzip "${volname##*/}".nii.gz -f

            done

            rm straight_ref.nii.gz
            rm warp_curve2straight.nii.gz
            rm warp_straight2curve.nii.gz
            rm straightening.cache
            rm resvol*.nii.gz
            mv fmri_spine_moco_denoised_icap.nii.gz ../fmri_spine_moco_denoised_icap.nii.gz

        fi
    done
done

####################################
# Display useful info for the log
end=`date +%s`
runtime=$((end-start))
echo
echo "~~~"
echo "SCT version: `sct_version`"
echo "Ran on:      `uname -nsr`"
echo "Duration:    $(($runtime / 3600))hrs $((($runtime / 60) % 60))min $(($runtime % 60))sec"
echo "~~~"
####################################